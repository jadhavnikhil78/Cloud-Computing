package utils

class StringsDAO() {
  
  /***********************************************************************
   * Hard coded Paths to Hadoop Home directory in my PC 
   * need to be removed while running in the clusters
   * *********************************************************************/ 
  var HADOOP_HOME_DIR = "hadoop.home.dir"
  var HADOOP_HOME_DIR_PATH = "C:\\Hadoop\\hadoop-common-2.2.0-bin-master\\"
  
  var ATTRIBUTES_FILE_NOT_FOUND = "The provided path for Attributes file is invalid"
  var EMPTY_STRING = " "
  var FILE_EMPTY_VALUE = "?"
  
  
}